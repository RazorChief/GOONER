"""
DSS Katalog Rekomendasi Game
CustomTkinter GUI  |  BFS + Dijkstra + SAW
Sidebar  : referensi UAS-TEST.py
Card     : referensi my-uas (dengan gambar dari assets/)
Tampilan : toggle Kartu / Tabel
"""

import customtkinter as ctk
from PIL import Image
import os, math, threading
from collections import defaultdict, deque
import heapq

# ── Asset path ────────────────────────────────────────────────
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")

# ============================================================
# DATABASE & KONSTANTA
# ============================================================
DATABASE_GAME = [
    {"id": "G1",  "nama": "Minecraft",               "genre": ["Sandbox"],    "harga": 538000, "rating": 9.0, "popularitas": 98},
    {"id": "G2",  "nama": "Terraria",                 "genre": ["Sandbox"],    "harga": 90000,  "rating": 9.2, "popularitas": 91},
    {"id": "G3",  "nama": "Stardew Valley",           "genre": ["Simulation"], "harga": 115000, "rating": 9.0, "popularitas": 88},
    {"id": "G4",  "nama": "Hollow Knight",            "genre": ["Action"],     "harga": 130000, "rating": 9.1, "popularitas": 85},
    {"id": "G5",  "nama": "Hades II",                 "genre": ["Action"],     "harga": 245000, "rating": 9.4, "popularitas": 90},
    {"id": "G6",  "nama": "Valorant",                 "genre": ["Shooter"],    "harga": 0,      "rating": 8.5, "popularitas": 95},
    {"id": "G7",  "nama": "Tekken",                   "genre": ["Fighting"],   "harga": 799000, "rating": 8.8, "popularitas": 82},
    {"id": "G8",  "nama": "Dragon Ball Xenoverse",    "genre": ["Fighting"],   "harga": 450000, "rating": 8.3, "popularitas": 78},
    {"id": "G9",  "nama": "Satisfactory",             "genre": ["Sandbox"],    "harga": 210000, "rating": 8.9, "popularitas": 84},
    {"id": "G10", "nama": "Zomboid",                  "genre": ["Shooter"],    "harga": 139000, "rating": 8.7, "popularitas": 80},
    {"id": "G11", "nama": "Fishing Simulator",        "genre": ["Simulation"], "harga": 0,      "rating": 7.5, "popularitas": 65},
    {"id": "G12", "nama": "7 Days to Die",            "genre": ["Sandbox"],    "harga": 338000, "rating": 8.2, "popularitas": 76},
    {"id": "G13", "nama": "Wuthering Wave",           "genre": ["RPG"],        "harga": 0,      "rating": 8.6, "popularitas": 87},
    {"id": "G14", "nama": "Blue Archive",             "genre": ["RPG"],        "harga": 0,      "rating": 8.4, "popularitas": 83},
    {"id": "G15", "nama": "Marvel Rivals",            "genre": ["Action"],     "harga": 0,      "rating": 8.5, "popularitas": 89},
    {"id": "G16", "nama": "House Flipper",            "genre": ["Simulation"], "harga": 206000, "rating": 8.3, "popularitas": 72},
    {"id": "G17", "nama": "Subnautica",               "genre": ["Sandbox"],    "harga": 350000, "rating": 9.1, "popularitas": 88},
    {"id": "G18", "nama": "Devil May Cry 5",          "genre": ["Action"],     "harga": 389000, "rating": 9.0, "popularitas": 86},
    {"id": "G19", "nama": "Limbus Company",           "genre": ["RPG"],        "harga": 0,      "rating": 8.7, "popularitas": 81},
    {"id": "G20", "nama": "Umamusume: Pretty Derby",  "genre": ["Simulation"], "harga": 0,      "rating": 8.2, "popularitas": 75},
]

EDGES_LAPORAN = [
    ("G1","G2","Genre sama",0.1),  ("G2","G3","Harga mirip",0.3), ("G3","G4","Harga mirip",0.3),
    ("G4","G5","Genre sama",0.1),  ("G5","G6","Harga mirip",0.5), ("G6","G10","Genre sama",0.1),
    ("G7","G8","Genre sama",0.1),  ("G8","G9","Harga mirip",0.3), ("G9","G12","Genre sama",0.1),
    ("G1","G9","Genre sama",0.1),  ("G1","G12","Genre sama",0.1), ("G1","G17","Genre sama",0.1),
    ("G2","G9","Genre sama",0.1),  ("G2","G12","Genre sama",0.1), ("G2","G17","Genre sama",0.1),
    ("G9","G17","Genre sama",0.1), ("G12","G17","Genre sama",0.1),
    ("G3","G11","Genre sama",0.1), ("G3","G16","Genre sama",0.1), ("G3","G20","Genre sama",0.1),
    ("G11","G16","Genre sama",0.1),("G11","G20","Genre sama",0.1),("G16","G20","Genre sama",0.1),
    ("G13","G14","Genre sama",0.1),("G13","G19","Genre sama",0.1),("G14","G19","Genre sama",0.1),
    ("G4","G15","Genre sama",0.1), ("G4","G18","Genre sama",0.1), ("G5","G15","Genre sama",0.1),
    ("G5","G18","Genre sama",0.1), ("G15","G18","Genre sama",0.1),("G3","G20","Harga mirip",0.3),
]

SEMUA_GENRE = sorted(set(g for game in DATABASE_GAME for g in game["genre"]))
BOBOT_SAW   = {"rating": 0.30, "harga": 0.20, "popularitas": 0.25, "kemiripan": 0.25}

# ============================================================
# TEMA & WARNA (dari my-uas)
# ============================================================
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

C = {
    "bg":         "#0d1117",
    "sidebar":    "#161b22",
    "card":       "#1c2128",
    "card_hover": "#21262d",
    "surface":    "#1c2128",
    "surface2":   "#21262d",
    "accent":     "#1f6feb",
    "accent2":    "#388bfd",
    "accent3":    "#3fb950",
    "green":      "#3fb950",
    "yellow":     "#d29922",
    "gold":       "#ffd700",
    "red":        "#f85149",
    "text":       "#e6edf3",
    "text_dim":   "#8b949e",
    "muted":      "#8b949e",
    "text_muted": "#484f58",
    "border":     "#30363d",
    "tag_bg":     "#21262d",
    "free":       "#3fb950",
    "paid":       "#d29922",
    "rank1":      "#ffd700",
    "rank2":      "#c0c0c0",
    "rank3":      "#cd7f32",
}

FONT_TITLE  = ("Segoe UI", 22, "bold")
FONT_HEAD   = ("Segoe UI", 14, "bold")
FONT_BODY   = ("Segoe UI", 12)
FONT_SMALL  = ("Segoe UI", 10)
FONT_TINY   = ("Segoe UI", 9)
FONT_MONO   = ("Consolas", 11)
FONT_MONO_S = ("Consolas", 10)

GENRE_COLORS = {
    "Action":     ("#f85149", "#2d1b1b"),
    "Sandbox":    ("#3fb950", "#1b2d1b"),
    "Simulation": ("#d29922", "#2d271b"),
    "RPG":        ("#a371f7", "#2a1b3d"),
    "Shooter":    ("#ff7b72", "#2d1b1b"),
    "Fighting":   ("#ffa657", "#2d221b"),
}

# ============================================================
# ALGORITMA: BFS + DIJKSTRA + SAW
# ============================================================
def bangun_graph_genre(database):
    graph = defaultdict(list)
    adjacency = defaultdict(set)
    id_to_game = {g["id"]: g for g in database}
    for game in database:
        for genre in game["genre"]:
            graph[genre].append(game["id"])
    for (u, v, _, __) in EDGES_LAPORAN:
        gu = id_to_game[u]["genre"][0]
        gv = id_to_game[v]["genre"][0]
        adjacency[gu].add(gv)
        adjacency[gv].add(gu)
    return graph, adjacency

def bfs_cari_kandidat(start_genre, graph_genre, adjacency, kedalaman=2):
    visited = set()
    queue = deque([(start_genre, 0)])
    kandidat_ids = set()
    while queue:
        genre, depth = queue.popleft()
        if genre in visited or depth > kedalaman:
            continue
        visited.add(genre)
        for gid in graph_genre.get(genre, []):
            kandidat_ids.add(gid)
        if depth < kedalaman:
            for tetangga in adjacency.get(genre, []):
                if tetangga not in visited:
                    queue.append((tetangga, depth + 1))
    return kandidat_ids

def hitung_kemiripan_genre(game_a, game_b):
    set_a, set_b = set(game_a["genre"]), set(game_b["genre"])
    union = len(set_a | set_b)
    return 1.0 if union == 0 else round(1.0 - len(set_a & set_b) / union, 4)

def bangun_graph_kemiripan(kandidat_ids, database):
    id_to_game = {g["id"]: g for g in database}
    graph = defaultdict(list)
    edge_index = {}
    for (u, v, _, bobot) in EDGES_LAPORAN:
        edge_index[(u, v)] = bobot
        edge_index[(v, u)] = bobot
    ids = list(kandidat_ids)
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            a, b = ids[i], ids[j]
            bobot = edge_index.get((a, b), hitung_kemiripan_genre(id_to_game[a], id_to_game[b]))
            graph[a].append((bobot, b))
            graph[b].append((bobot, a))
    return graph, id_to_game

def dijkstra(graph, start_id, kandidat_ids):
    dist = {gid: float('inf') for gid in kandidat_ids}
    dist[start_id] = 0
    pq = [(0, start_id)]
    while pq:
        d, u = heapq.heappop(pq)
        if d > dist[u]:
            continue
        for (w, v) in graph.get(u, []):
            nd = dist[u] + w
            if nd < dist[v]:
                dist[v] = nd
                heapq.heappush(pq, (nd, v))
    return dist

def normalisasi_benefit(nl):
    m = max(nl) or 1
    return [v / m for v in nl]

def normalisasi_cost(nl):
    m = min((v for v in nl if v > 0), default=1)
    return [m / v if v > 0 else 1.0 for v in nl]

def hitung_saw(games, dist_kemiripan):
    if not games:
        return []
    ratings     = [g["rating"]      for g in games]
    harga       = [g["harga"]       for g in games]
    popularitas = [g["popularitas"] for g in games]
    kemiripan   = [dist_kemiripan.get(g["id"], float('inf')) for g in games]
    max_k = max((k for k in kemiripan if k != float('inf')), default=1) + 1
    kemiripan = [k if k != float('inf') else max_k for k in kemiripan]
    nr = normalisasi_benefit(ratings)
    nh = normalisasi_cost(harga)
    np_ = normalisasi_benefit(popularitas)
    nk = normalisasi_cost(kemiripan)
    hasil = []
    for i, game in enumerate(games):
        skor = (BOBOT_SAW["rating"] * nr[i] + BOBOT_SAW["harga"] * nh[i] +
                BOBOT_SAW["popularitas"] * np_[i] + BOBOT_SAW["kemiripan"] * nk[i])
        hasil.append({**game, "skor_saw": round(skor, 4)})
    hasil.sort(key=lambda x: x["skor_saw"], reverse=True)
    for rank, item in enumerate(hasil, 1):
        item["rank"] = rank
    return hasil

def terapkan_filter(database, genre_filter, harga_min, harga_maks):
    hasil = []
    # Kasus khusus: min=0 dan maks=0 → hanya game free
    free_only = (harga_min == 0 and harga_maks == 0)
    for g in database:
        h = g["harga"]
        if free_only:
            if h != 0:
                continue
        else:
            if h < harga_min:
                continue
            if harga_maks != float('inf') and h > harga_maks:
                continue
        if genre_filter is not None:
            if not any(gn in genre_filter for gn in g["genre"]):
                continue
        hasil.append(g)
    return hasil

def jalankan_rekomendasi(genre_user, harga_min, harga_maks):
    graph_genre, adjacency_genre = bangun_graph_genre(DATABASE_GAME)
    kandidat_ids = set()
    genre_bfs = SEMUA_GENRE if genre_user is None else genre_user
    for genre in genre_bfs:
        kandidat_ids.update(bfs_cari_kandidat(genre, graph_genre, adjacency_genre, kedalaman=2))
    kandidat = terapkan_filter(
        [g for g in DATABASE_GAME if g["id"] in kandidat_ids],
        genre_filter=None, harga_min=harga_min, harga_maks=harga_maks)
    if genre_user:
        kandidat = [g for g in kandidat if any(gn in genre_user for gn in g["genre"])]
    kandidat_ids = {g["id"] for g in kandidat}
    if not kandidat_ids:
        return None
    graph_kemiripan, id_to_game = bangun_graph_kemiripan(kandidat_ids, DATABASE_GAME)
    if genre_user is None:
        start_id = max(kandidat_ids, key=lambda gid: id_to_game[gid]["popularitas"])
    else:
        start_id = max(kandidat_ids, key=lambda gid: len(set(id_to_game[gid]["genre"]) & set(genre_user)))
    dist_kemiripan = dijkstra(graph_kemiripan, start_id, kandidat_ids)
    return hitung_saw([id_to_game[gid] for gid in kandidat_ids], dist_kemiripan)

def fmt_harga(h):
    return "Free" if h == 0 else f"Rp {h:,}"

# ============================================================
# KOMPONEN: GAME GRID (Card View, dari my-uas)
# ============================================================
class GameGrid(ctk.CTkScrollableFrame):
    CARD_W = 210
    CARD_H = 300
    IMG_W  = 210
    IMG_H  = 140
    COLS   = 4

    def __init__(self, master, **kw):
        super().__init__(master, fg_color=C["bg"], **kw)
        self._image_refs = []

    def clear(self):
        for w in self.winfo_children():
            w.destroy()
        self._image_refs.clear()

    def populate(self, games, badge_mode="none"):
        self.clear()
        for idx, game in enumerate(games):
            card = self._make_card(game, badge_mode)
            card.grid(row=idx // self.COLS, column=idx % self.COLS,
                      padx=10, pady=10, sticky="nw")

    def _make_card(self, game, badge_mode):
        card = ctk.CTkFrame(self, width=self.CARD_W, height=self.CARD_H,
                            fg_color=C["card"], corner_radius=10,
                            border_width=1, border_color=C["border"])
        card.grid_propagate(False)

        # ── Cover image ───────────────────────────────────────
        img_frame = ctk.CTkFrame(card, width=self.IMG_W, height=self.IMG_H,
                                 fg_color=C["card_hover"], corner_radius=8)
        img_frame.place(x=0, y=0)
        img_frame.grid_propagate(False)

        img_path = os.path.join(ASSET_DIR, f"{game['id']}.png")
        try:
            pil_img = Image.open(img_path).resize((self.IMG_W, self.IMG_H), Image.LANCZOS)
            ctk_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img,
                                   size=(self.IMG_W, self.IMG_H))
            self._image_refs.append(ctk_img)
            ctk.CTkLabel(img_frame, image=ctk_img, text="").place(x=0, y=0)
        except Exception:
            ctk.CTkLabel(img_frame, text=game["id"], font=FONT_TITLE,
                         text_color=C["text_dim"]).place(relx=0.5, rely=0.5, anchor="center")

        # ── Genre tag ─────────────────────────────────────────
        genre = game["genre"][0]
        gc, gbg = GENRE_COLORS.get(genre, (C["accent2"], C["tag_bg"]))
        ctk.CTkLabel(img_frame, text=f" {genre} ", font=FONT_TINY,
                     text_color=gc, fg_color=gbg, corner_radius=4).place(x=7, y=7)

        # ── Rating badge ──────────────────────────────────────
        ctk.CTkLabel(img_frame, text=f"★ {game['rating']}",
                     font=("Segoe UI", 10, "bold"),
                     text_color="#ffd700", fg_color="#0d1117",
                     corner_radius=4).place(relx=1.0, x=-7, y=7, anchor="ne")

        # ── Rank badge (rekomendasi) ──────────────────────────
        if badge_mode == "rank" and "rank" in game:
            rank_colors = {1: C["rank1"], 2: C["rank2"], 3: C["rank3"]}
            rc = rank_colors.get(game["rank"], C["accent2"])
            ctk.CTkLabel(img_frame, text=f"#{game['rank']}",
                         font=("Segoe UI", 11, "bold"),
                         text_color=rc, fg_color="#0d1117",
                         corner_radius=4).place(x=7, y=self.IMG_H - 26)

        # ── Info di bawah gambar ──────────────────────────────
        info_y = self.IMG_H + 6
        name = game["nama"][:20] + "…" if len(game["nama"]) > 22 else game["nama"]
        ctk.CTkLabel(card, text=name, font=("Segoe UI", 12, "bold"),
                     text_color=C["text"], anchor="w",
                     wraplength=self.CARD_W - 16).place(x=8, y=info_y)

        price_color = C["free"] if game["harga"] == 0 else C["paid"]
        ctk.CTkLabel(card, text=fmt_harga(game["harga"]),
                     font=("Segoe UI", 11, "bold"),
                     text_color=price_color).place(x=8, y=info_y + 24)

        if "skor_saw" in game:
            ctk.CTkLabel(card, text=f"SAW: {game['skor_saw']:.4f}",
                         font=FONT_TINY, text_color=C["text_dim"]).place(x=8, y=info_y + 46)

        # ── Hover effect ──────────────────────────────────────
        def on_enter(e, c=card): c.configure(fg_color=C["card_hover"], border_color=C["accent"])
        def on_leave(e, c=card): c.configure(fg_color=C["card"], border_color=C["border"])
        for widget in self._all_children(card):
            widget.bind("<Enter>", on_enter)
            widget.bind("<Leave>", on_leave)
        card.bind("<Enter>", on_enter)
        card.bind("<Leave>", on_leave)
        return card

    def _all_children(self, widget):
        result = []
        for child in widget.winfo_children():
            result.append(child)
            result.extend(self._all_children(child))
        return result

# ============================================================
# KOMPONEN: TABLE VIEW (dari UAS-TEST.py)
# ============================================================
class GameTable(ctk.CTkScrollableFrame):
    COLS   = ["Rank", "ID", "Nama Game", "Genre", "Harga", "Rating", "Pop.", "Skor SAW"]
    WIDTHS = [50,     55,   195,         90,      130,     70,       50,     85]

    def __init__(self, master, **kw):
        super().__init__(master, fg_color=C["surface"], corner_radius=12, **kw)

    def clear(self):
        for w in self.winfo_children():
            w.destroy()

    def populate(self, games, badge_mode="none"):
        self.clear()
        # Header
        hdr = ctk.CTkFrame(self, fg_color=C["surface2"], corner_radius=8)
        hdr.pack(fill="x", padx=8, pady=(8, 2))
        for i, (col, w) in enumerate(zip(self.COLS, self.WIDTHS)):
            ctk.CTkLabel(hdr, text=col, font=FONT_MONO_S,
                         text_color=C["muted"], width=w, anchor="w"
                         ).grid(row=0, column=i, padx=8, pady=6, sticky="w")

        for game in games:
            rank_color = {1: C["rank1"], 2: C["rank2"], 3: C["rank3"]}.get(
                game.get("rank", 0), C["muted"])
            row_f = ctk.CTkFrame(self, fg_color="transparent", corner_radius=6)
            row_f.pack(fill="x", padx=8, pady=1)

            rank_str = f"#{game['rank']}" if "rank" in game else "—"
            saw_str  = str(game["skor_saw"]) if "skor_saw" in game else "—"

            vals = [
                (rank_str,                rank_color),
                (game["id"],              C["muted"]),
                (game["nama"],            C["text"]),
                (game["genre"][0],        GENRE_COLORS.get(game["genre"][0], (C["accent2"],))[0]),
                (fmt_harga(game["harga"]),C["free"] if game["harga"] == 0 else C["paid"]),
                (f"★ {game['rating']:.1f}", C["gold"]),
                (str(game["popularitas"]),C["text"]),
                (saw_str,                 C["accent2"]),
            ]
            for i, ((val, color), w) in enumerate(zip(vals, self.WIDTHS)):
                font = FONT_MONO_S if i in (0, 1, 7) else FONT_SMALL
                ctk.CTkLabel(row_f, text=val, font=font,
                             text_color=color, width=w, anchor="w"
                             ).grid(row=0, column=i, padx=8, pady=6, sticky="w")

            ctk.CTkFrame(self, fg_color=C["border"], height=1).pack(fill="x", padx=16)

# ============================================================
# APLIKASI UTAMA
# ============================================================
class DSSApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("🎮  DSS Katalog Rekomendasi Game")
        self.geometry("1380x840")
        self.minsize(1100, 700)
        self.configure(fg_color=C["bg"])

        self._current_view = "catalog"   # 'catalog' | 'rekomendasi'
        self._view_mode    = "card"      # 'card'    | 'table'
        self._current_data = []

        self._build_layout()
        self._show_catalog()

    # ── Layout utama ─────────────────────────────────────────
    def _build_layout(self):
        # Sidebar (kiri)
        self.sidebar = ctk.CTkFrame(self, width=270, fg_color=C["sidebar"],
                                    corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        self._build_sidebar()

        # Area konten (kanan)
        self.main_area = ctk.CTkFrame(self, fg_color=C["bg"], corner_radius=0)
        self.main_area.pack(side="left", fill="both", expand=True)
        self._build_main_area()

    # ── SIDEBAR ──────────────────────────────────────────────
    def _build_sidebar(self):
        sb = self.sidebar

        # Logo
        logo_f = ctk.CTkFrame(sb, fg_color="transparent")
        logo_f.pack(fill="x", padx=20, pady=(24, 4))
        ctk.CTkLabel(logo_f, text="🎮", font=("Segoe UI", 28)).pack(side="left")
        ctk.CTkLabel(logo_f, text=" DSS Game\n  Catalog",
                     font=("Segoe UI", 16, "bold"),
                     text_color=C["text"], justify="left").pack(side="left")
        ctk.CTkLabel(sb, text="BFS · Dijkstra · SAW",
                     font=FONT_TINY, text_color=C["text_muted"]).pack(pady=(0, 16))

        ctk.CTkFrame(sb, height=1, fg_color=C["border"]).pack(fill="x", padx=16)

        # Navigasi
        ctk.CTkLabel(sb, text="  MENU", font=("Segoe UI", 10, "bold"),
                     text_color=C["text_muted"], anchor="w").pack(fill="x", padx=20, pady=(16, 4))
        self.btn_catalog   = self._sidebar_btn(sb, "📋  Lihat Katalog",    self._show_catalog)
        self.btn_recommend = self._sidebar_btn(sb, "🏆  Rekomendasi Game", self._show_recommend)

        ctk.CTkFrame(sb, height=1, fg_color=C["border"]).pack(fill="x", padx=16, pady=(16, 0))

        # ── FILTER FRAME (hanya tampil di Rekomendasi) ────────
        self.filter_frame = ctk.CTkFrame(sb, fg_color="transparent")
        # Tidak di-pack dulu; akan ditampilkan hanya saat Rekomendasi

        ff = self.filter_frame
        ctk.CTkLabel(ff, text="  FILTER REKOMENDASI", font=("Segoe UI", 10, "bold"),
                     text_color=C["yellow"], anchor="w").pack(fill="x", padx=20, pady=(12, 4))

        ctk.CTkLabel(ff, text="Genre", font=FONT_HEAD,
                     text_color=C["text"], anchor="w").pack(fill="x", padx=18, pady=(0, 6))

        # Chip scrollable
        self.selected_genres: set = set()
        chip_outer = ctk.CTkScrollableFrame(ff, fg_color=C["surface2"],
                                            corner_radius=8, height=148)
        chip_outer.pack(fill="x", padx=18, pady=(0, 12))

        self.btn_all = ctk.CTkButton(
            chip_outer, text="✦ Semua Genre",
            font=FONT_SMALL, height=30, corner_radius=20,
            fg_color=C["accent3"], hover_color="#3db5ad",
            text_color="#ffffff",
            command=lambda: self._toggle_genre("ALL"))
        self.btn_all.pack(fill="x", pady=(0, 4))

        self.genre_btns: dict = {}
        for g in SEMUA_GENRE:
            gc, _ = GENRE_COLORS.get(g, (C["accent2"], C["tag_bg"]))
            b = ctk.CTkButton(
                chip_outer, text=g,
                font=FONT_SMALL, height=30, corner_radius=20,
                fg_color=C["surface"], hover_color=C["accent"],
                text_color=C["text"], border_width=1, border_color=C["border"],
                command=lambda gn=g: self._toggle_genre(gn))
            b.pack(fill="x", pady=2)
            self.genre_btns[g] = b

        ctk.CTkLabel(ff, text="Jangkauan Harga (Rp)", font=FONT_SMALL,
                     text_color=C["text_dim"], anchor="w").pack(fill="x", padx=20, pady=(0, 4))

        price_f = ctk.CTkFrame(ff, fg_color="transparent")
        price_f.pack(fill="x", padx=16, pady=(0, 6))
        price_f.columnconfigure(1, weight=1)

        ctk.CTkLabel(price_f, text="Min", font=FONT_TINY,
                     text_color=C["text_muted"]).grid(row=0, column=0, sticky="w", pady=2)
        self.entry_min = ctk.CTkEntry(price_f, placeholder_text="0 = mulai dari 0",
                                      height=32, font=FONT_SMALL,
                                      fg_color=C["card"], border_color=C["border"],
                                      text_color=C["text"])
        self.entry_min.grid(row=0, column=1, sticky="ew", padx=(8, 0), pady=2)

        ctk.CTkLabel(price_f, text="Maks", font=FONT_TINY,
                     text_color=C["text_muted"]).grid(row=1, column=0, sticky="w", pady=2)
        self.entry_maks = ctk.CTkEntry(price_f, placeholder_text="kosong = ∞  |  0 = Free",
                                       height=32, font=FONT_SMALL,
                                       fg_color=C["card"], border_color=C["border"],
                                       text_color=C["text"])
        self.entry_maks.grid(row=1, column=1, sticky="ew", padx=(8, 0), pady=2)

        # Hint teks
        ctk.CTkLabel(ff, text="💡 Min=0 & Maks=0 → hanya game Free",
                     font=FONT_TINY, text_color=C["text_muted"],
                     wraplength=240, justify="left").pack(fill="x", padx=20, pady=(0, 6))

        # Tombol terapkan & reset
        ctk.CTkButton(ff, text="▶  Cari Rekomendasi",
                      height=38, font=("Segoe UI", 12, "bold"),
                      fg_color=C["accent"], hover_color=C["accent2"],
                      corner_radius=8,
                      command=self._apply_filter).pack(fill="x", padx=16, pady=(10, 4))

        ctk.CTkButton(ff, text="↺  Reset Filter",
                      height=32, font=FONT_SMALL,
                      fg_color="transparent", hover_color=C["card"],
                      text_color=C["text_dim"],
                      border_width=1, border_color=C["border"],
                      corner_radius=8,
                      command=self._reset_filter).pack(fill="x", padx=16, pady=(0, 8))

        # ─────────────────────────────────────────────────────
        self.lbl_status = ctk.CTkLabel(sb, text="", font=FONT_TINY,
                                       text_color=C["muted"], wraplength=240)
        self.lbl_status.pack(padx=16, pady=(4, 8))

        # Spacer
        ctk.CTkFrame(sb, fg_color="transparent").pack(fill="both", expand=True)

        ctk.CTkFrame(sb, height=1, fg_color=C["border"]).pack(fill="x", padx=16)
        ctk.CTkButton(sb, text="⏻  Keluar",
                      height=38, font=FONT_BODY,
                      fg_color="transparent", hover_color=C["red"],
                      text_color=C["red"],
                      border_width=1, border_color=C["red"],
                      corner_radius=8,
                      command=self.destroy).pack(fill="x", padx=16, pady=16)

    def _sidebar_btn(self, parent, text, cmd):
        btn = ctk.CTkButton(parent, text=text, anchor="w",
                            height=40, font=FONT_BODY,
                            fg_color="transparent", hover_color=C["card"],
                            text_color=C["text"], corner_radius=8,
                            command=cmd)
        btn.pack(fill="x", padx=10, pady=2)
        return btn

    def _toggle_genre(self, genre: str):
        if genre == "ALL":
            self.selected_genres.clear()
            self.btn_all.configure(fg_color=C["accent3"], text_color="#fff")
            for b in self.genre_btns.values():
                b.configure(fg_color=C["surface"], text_color=C["text"])
        else:
            if genre in self.selected_genres:
                self.selected_genres.discard(genre)
                self.genre_btns[genre].configure(fg_color=C["surface"], text_color=C["text"])
            else:
                self.selected_genres.add(genre)
                gc, _ = GENRE_COLORS.get(genre, (C["accent2"], C["tag_bg"]))
                self.genre_btns[genre].configure(fg_color=C["accent"], text_color="#fff")
            if self.selected_genres:
                self.btn_all.configure(fg_color=C["surface"], text_color=C["muted"])
            else:
                self.btn_all.configure(fg_color=C["accent3"], text_color="#fff")

    def _get_genre_filter(self):
        return list(self.selected_genres) if self.selected_genres else None

    # ── MAIN AREA ─────────────────────────────────────────────
    def _build_main_area(self):
        ma = self.main_area

        # Top bar
        top_bar = ctk.CTkFrame(ma, height=64, fg_color=C["sidebar"], corner_radius=0)
        top_bar.pack(fill="x")
        top_bar.pack_propagate(False)

        self.lbl_view_title = ctk.CTkLabel(top_bar, text="📋  Katalog Game",
                                           font=FONT_TITLE, text_color=C["text"], anchor="w")
        self.lbl_view_title.pack(side="left", padx=24, pady=16)

        # Badge notifikasi bulat (jumlah game)
        self.badge_frame = ctk.CTkFrame(top_bar, fg_color=C["accent"],
                                        corner_radius=14, width=52, height=28)
        self.badge_frame.pack(side="right", padx=16, pady=18)
        self.badge_frame.pack_propagate(False)
        self.lbl_count = ctk.CTkLabel(self.badge_frame, text="20",
                                      font=("Segoe UI", 11, "bold"),
                                      text_color="#ffffff")
        self.lbl_count.place(relx=0.5, rely=0.5, anchor="center")

        # Toggle Kartu / Tabel
        self.seg_view = ctk.CTkSegmentedButton(
            top_bar, values=["Kartu", "Tabel"],
            font=FONT_SMALL,
            fg_color=C["card"],
            selected_color=C["accent"],
            unselected_color=C["card"],
            command=self._on_view_toggle)
        self.seg_view.set("Kartu")
        self.seg_view.pack(side="right", padx=(0, 12), pady=16)

        # Bobot SAW strip
        weights_strip = ctk.CTkFrame(ma, height=28, fg_color=C["card"], corner_radius=0)
        weights_strip.pack(fill="x")
        weights_strip.pack_propagate(False)
        ctk.CTkLabel(weights_strip,
                     text=(f"Bobot SAW — Rating: {BOBOT_SAW['rating']} · "
                           f"Harga: {BOBOT_SAW['harga']} · "
                           f"Popularitas: {BOBOT_SAW['popularitas']} · "
                           f"Kemiripan: {BOBOT_SAW['kemiripan']}"),
                     font=FONT_TINY, text_color=C["text_muted"]).pack(side="left", padx=16)

        # Konten area — card grid
        self.game_grid = GameGrid(ma)
        self.game_grid.pack(fill="both", expand=True)

        # Konten area — tabel (tersembunyi saat awal)
        self.game_table = GameTable(ma)

        # Loading / empty label
        self.lbl_loading = ctk.CTkLabel(ma, text="⏳  Memproses...",
                                        font=("Segoe UI", 16, "bold"),
                                        text_color=C["muted"])
        self.lbl_empty = ctk.CTkLabel(ma,
                                      text="😔\n\nTidak ada game yang sesuai filter.\nCoba ubah genre atau jangkauan harga.",
                                      font=FONT_HEAD, text_color=C["muted"],
                                      justify="center")

    # ── VIEW SWITCHING ────────────────────────────────────────
    def _show_content(self, games, badge_mode="none"):
        """Tampilkan data ke widget aktif (kartu atau tabel)."""
        self._current_data = games
        self.lbl_loading.place_forget()
        self.lbl_empty.place_forget()

        if not games:
            self.game_grid.pack_forget()
            self.game_table.pack_forget()
            self.lbl_empty.place(relx=0.5, rely=0.5, anchor="center")
            return

        if self._view_mode == "card":
            self.game_table.pack_forget()
            self.game_grid.pack(fill="both", expand=True)
            self.game_grid.populate(games, badge_mode=badge_mode)
        else:
            self.game_grid.pack_forget()
            self.game_table.pack(fill="both", expand=True)
            self.game_table.populate(games, badge_mode=badge_mode)

    def _on_view_toggle(self, val):
        self._view_mode = "card" if val == "Kartu" else "table"
        if self._current_data:
            badge = "rank" if self._current_view == "rekomendasi" else "none"
            self._show_content(self._current_data, badge_mode=badge)

    # ── VIEWS ─────────────────────────────────────────────────
    def _show_catalog(self):
        self._current_view = "catalog"
        self._set_active_btn(self.btn_catalog)
        self.lbl_view_title.configure(text="📋  Katalog Game")
        # Sembunyikan panel filter di katalog
        self.filter_frame.pack_forget()
        data = sorted(DATABASE_GAME, key=lambda x: x["popularitas"], reverse=True)
        self.lbl_count.configure(text=str(len(data)))
        self.lbl_status.configure(text=f"{len(data)} game ditampilkan")
        self._show_content(data, badge_mode="none")

    def _show_recommend(self):
        self._current_view = "rekomendasi"
        self._set_active_btn(self.btn_recommend)
        self.lbl_view_title.configure(text="🏆  Rekomendasi Game")
        # Tampilkan panel filter hanya di rekomendasi
        self.filter_frame.pack(fill="x", before=self.lbl_status)
        self._run_recommendation()

    def _run_recommendation(self):
        self.lbl_loading.place(relx=0.5, rely=0.5, anchor="center")
        self.game_grid.pack_forget()
        self.game_table.pack_forget()
        self.lbl_status.configure(text="Memproses pipeline...")

        def run():
            genre_filter      = self._get_genre_filter()
            harga_min, harga_maks = self._parse_harga()
            hasil = jalankan_rekomendasi(genre_filter, harga_min, harga_maks)
            self.after(0, lambda: self._finish_recommendation(hasil))

        threading.Thread(target=run, daemon=True).start()

    def _finish_recommendation(self, hasil):
        self.lbl_loading.place_forget()
        if hasil is None:
            self.lbl_count.configure(text="0")
            self.lbl_status.configure(text="Ubah filter dan coba lagi.")
            self._show_content([], badge_mode="rank")
        else:
            self.lbl_count.configure(text=str(len(hasil)))
            label_genre = ", ".join(self._get_genre_filter()) if self._get_genre_filter() else "Semua Genre"
            self.lbl_status.configure(text=f"✅ {len(hasil)} kandidat · {label_genre}")
            self._show_content(hasil, badge_mode="rank")

    # ── FILTER ────────────────────────────────────────────────
    def _get_filtered_data(self):
        # Digunakan hanya oleh rekomendasi
        genre_filter = self._get_genre_filter()
        harga_min, harga_maks = self._parse_harga()
        return terapkan_filter(DATABASE_GAME, genre_filter, harga_min, harga_maks)

    def _parse_harga(self):
        raw_min = self.entry_min.get().strip()
        raw_maks = self.entry_maks.get().strip()
        try:
            harga_min = int(raw_min) if raw_min != "" else 0
        except ValueError:
            harga_min = 0
        try:
            if raw_maks == "":
                # Kosong = tidak ada batas atas
                harga_maks = float('inf')
            else:
                raw_val = int(raw_maks)
                # Jika min=0 dan maks=0 → tampilkan HANYA game free
                harga_maks = raw_val  # bisa 0 (free only) atau nilai positif
        except ValueError:
            harga_maks = float('inf')
        return harga_min, harga_maks

    def _apply_filter(self):
        if self._current_view == "catalog":
            self._show_catalog()
        else:
            self._run_recommendation()

    def _reset_filter(self):
        self.selected_genres.clear()
        self.btn_all.configure(fg_color=C["accent3"], text_color="#fff")
        for b in self.genre_btns.values():
            b.configure(fg_color=C["surface"], text_color=C["text"])
        self.entry_min.delete(0, "end")
        self.entry_maks.delete(0, "end")
        self.lbl_status.configure(text="")
        self._run_recommendation()

    # ── UTIL ──────────────────────────────────────────────────
    def _set_active_btn(self, active_btn):
        for btn in (self.btn_catalog, self.btn_recommend):
            if btn == active_btn:
                btn.configure(fg_color=C["card"], text_color=C["accent2"])
            else:
                btn.configure(fg_color="transparent", text_color=C["text"])

# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    app = DSSApp()
    app.mainloop()