"""
Generate placeholder game cover images for all 20 games.
Each cover is 220x220 with a unique color scheme and game ID text.
"""
from PIL import Image, ImageDraw, ImageFont
import os

GAMES = [
    ("G1",  "Minecraft",              "#4CAF50", "#1B5E20"),
    ("G2",  "Terraria",               "#8BC34A", "#33691E"),
    ("G3",  "Stardew Valley",         "#FF9800", "#E65100"),
    ("G4",  "Hollow Knight",          "#5C6BC0", "#1A237E"),
    ("G5",  "Hades II",               "#E53935", "#7B1FA2"),
    ("G6",  "Valorant",               "#FF1744", "#D50000"),
    ("G7",  "Tekken",                 "#FFC107", "#FF6F00"),
    ("G8",  "Dragon Ball Xenoverse",  "#FF8F00", "#E65100"),
    ("G9",  "Satisfactory",           "#00ACC1", "#006064"),
    ("G10", "Zomboid",                "#558B2F", "#1B5E20"),
    ("G11", "Fishing Simulator",      "#29B6F6", "#01579B"),
    ("G12", "7 Days to Die",          "#BF360C", "#4E342E"),
    ("G13", "Wuthering Wave",         "#1565C0", "#0D47A1"),
    ("G14", "Blue Archive",           "#42A5F5", "#0D47A1"),
    ("G15", "Marvel Rivals",          "#C62828", "#B71C1C"),
    ("G16", "House Flipper",          "#F9A825", "#F57F17"),
    ("G17", "Subnautica",             "#006064", "#004D40"),
    ("G18", "Devil May Cry 5",        "#880E4F", "#4A148C"),
    ("G19", "Limbus Company",         "#AD1457", "#880E4F"),
    ("G20", "Umamusume",              "#F48FB1", "#880E4F"),
]

SIZE = 220

def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def generate_cover(game_id, name, color1, color2, path):
    img = Image.new("RGB", (SIZE, SIZE), color=hex_to_rgb(color1))
    draw = ImageDraw.Draw(img)

    # Gradient-like triangular split
    c2 = hex_to_rgb(color2)
    draw.polygon([(SIZE, 0), (SIZE, SIZE), (0, SIZE)], fill=c2)

    # Diagonal grid lines for texture
    c1r = hex_to_rgb(color1)
    line_color = tuple(min(255, int(c * 1.3)) for c in c2)
    for i in range(0, SIZE*2, 30):
        draw.line([(i, 0), (0, i)], fill=line_color, width=1)
        draw.line([(SIZE, i - SIZE), (i, SIZE)], fill=line_color, width=1)

    # Central game ID badge
    badge_r = 38
    cx, cy = SIZE // 2, SIZE // 2 - 15
    draw.ellipse([cx - badge_r, cy - badge_r, cx + badge_r, cy + badge_r],
                 fill=(255, 255, 255, 200))

    try:
        font_big = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
        font_sm  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
    except:
        font_big = ImageFont.load_default()
        font_sm  = font_big

    # ID text
    bbox = draw.textbbox((0, 0), game_id, font=font_big)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text((cx - tw // 2, cy - th // 2 - 2), game_id, fill=c2, font=font_big)

    # Name text below badge
    words = name.split()
    lines = []
    line = ""
    for w in words:
        test = f"{line} {w}".strip()
        bbox2 = draw.textbbox((0, 0), test, font=font_sm)
        if bbox2[2] - bbox2[0] > SIZE - 20:
            lines.append(line)
            line = w
        else:
            line = test
    if line:
        lines.append(line)

    y_text = cy + badge_r + 8
    for ln in lines:
        bbox3 = draw.textbbox((0, 0), ln, font=font_sm)
        lw = bbox3[2] - bbox3[0]
        draw.text((cx - lw // 2, y_text), ln, fill=(255, 255, 255), font=font_sm)
        y_text += 14

    # Bottom bar
    bar_h = 22
    draw.rectangle([0, SIZE - bar_h, SIZE, SIZE], fill=c2)

    # "PLACEHOLDER" label in bar
    ph_text = "GAME COVER"
    bbox4 = draw.textbbox((0, 0), ph_text, font=font_sm)
    pw = bbox4[2] - bbox4[0]
    draw.text(((SIZE - pw) // 2, SIZE - bar_h + 5), ph_text, fill=(255,255,255,180), font=font_sm)

    img.save(path)
    print(f"  Created: {path}")

os.makedirs("assets", exist_ok=True)
for gid, name, c1, c2 in GAMES:
    fname = f"assets/{gid}.png"
    generate_cover(gid, name, c1, c2, fname)

print("\nDone! All 20 placeholder covers generated.")
